import React, { useState } from 'react';
import ModalLogin from './ModalLogin';
import ComponenteMain from './ComponenteMain';
import Entrar from './Entrar';

function App() {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    const openModal = () => {
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };

    const handleLoginSuccess = () => {
        setIsLoggedIn(true); // Marca que o usuário está logado
        alert('Login realizado com sucesso!');
    };

    return (
        <div className="App">
            <header>
                <h1>FaculHub – O Curso Certo Para Você</h1>
                <br/><br/><br/><br/>
                <img src='instagram.webp' alt='Instagram' width={60}/>
                <img src='twitter.png' alt='Twitter' width={60}/>
            </header>

            <main>
                <div className="Esquerda">
                    <br/>
                    {!isLoggedIn && <Entrar onClick={openModal} />}
                    <br/>
                    <img className="LogoFaculHub" src="logo_faculhub.png" alt="Logo FaculHub"/>
                    <p className="Inscrições">Inscrições: 7</p>
                </div>

                <div className="Direita">
                    <ComponenteMain />
                </div>
            </main>

            {/* Modal de login */}
            <ModalLogin
                isOpen={isModalOpen}
                onClose={closeModal}
                onLoginSuccess={handleLoginSuccess}
            />
        </div>
    );
}

export default App;