// Componente Perfil.js
import React from 'react';

const Perfil = ({ usuario }) => {
  return (
    <div className="perfil">
      <img src={usuario.imagem} alt="Foto de perfil" className="imagem-perfil"/>
      <h2>{usuario.nome}</h2>
      <p>Inscrições: {usuario.inscricoes.length}</p>
    </div>
  );
};

export default Perfil;
