// ModalLogin.js
import React, { useState } from 'react';

const ModalLogin = ({ isOpen, onClose, onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    // Aqui você vai substituir pela verificação real no banco de dados.
    const fakeDb = [
      { email: 'usuario@exemplo.com', senha: 'senha123' }
    ];

    const user = fakeDb.find(u => u.email === email && u.senha === senha);
    
    if (user) {
      onLoginSuccess(); // Sucesso no login
    } else {
      setError('Usuário ou senha incorretos');
    }
  };

  if (!isOpen) return null; // Não renderiza se o modal não estiver aberto.

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h2>Login</h2>
        {error && <p className="error">{error}</p>}
        <div>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ borderColor: error ? 'red' : '' }}
          />
        </div>
        <div>
          <input
            type="password"
            placeholder="Senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            style={{ borderColor: error ? 'red' : '' }}
          />
        </div>
        <div className="modal-actions">
          <button className="cancel" onClick={onClose}>Cancelar</button>
          <button className="enter" onClick={handleLogin}>Entrar</button>
        </div>
      </div>
    </div>
  );
};

export default ModalLogin;