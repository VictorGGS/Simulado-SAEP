function ComponenteMain() {
    return(
        <>
        <div className="cabeçalho">
            <h2>Cursos</h2>
        </div>
        <div className='InteligênciaArtificial'>

            <h3>Inteligência Artificial</h3>
            <h3 className='PUC-MG'>PUC-MG</h3>
            
            <img className='InteligênciaArtificial' src='inteligencia_artificial.png' alt="Inteligência Artificial" width={600}/>
                                            <br/>
            <div className="barra">
                <img src='flecha_cima_vazia.svg' alt='Flecha'/>
                <p>4</p>
                <img className='Chat' src='chat.svg' alt='Chat'/>
                <p>1</p>
            </div>
        </div>
        <div className='Eletromecânica'>
            <h3>Eletromecânica</h3>
            <h3 className='PUC-MG'>PUC-MG</h3>
                                            <br/>
            <img className='Eletromecânica' src='eletromecanica.png' alt='Eletromecânica' width={600}/>
                                            <br/>                           
            <div className="barra">
                <img src='flecha_cima_vazia.svg' alt='Flecha'/>
                <p>3</p>
                <img className='Chat' src='chat.svg' alt='Chat'/>
                <p>1</p>
            </div>
        </div>
        </>
    )
}

export default ComponenteMain;