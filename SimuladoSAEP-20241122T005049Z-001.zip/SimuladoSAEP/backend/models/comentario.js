const Sequelize = require("sequelize");
const database = require("../db");
const comentario = database.define("comentario",
  {
    id_comentario: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      allowNull: false,
      autoIncrement: true,
    },
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      allowNull: false,
      references: {
        model: "empresa",
        key: "id",
      },
      onDelete: "CASCADE",
    },
    id_curso: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      allowNull: false,
      references: {
        model: "curso",
        key: "id_curso",
      },
      onDelete: "CASCADE",
    },
  },
  {
    freezeTableName: true,
    timestamps: false,
  }
);
module.exports = comentario;