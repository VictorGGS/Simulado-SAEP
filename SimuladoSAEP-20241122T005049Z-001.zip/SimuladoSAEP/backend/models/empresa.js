const Sequelize = require("sequelize");
const database = require("../db");
const empresa = database.define("empresa",
  {
    id_empresa: {
      type: Sequelize.INTEGER, 
      primaryKey: true, 
      allowNull: false, 
      autoIncrement: true, 
    },
    nome: {
      type: Sequelize.TEXT,
    },
    logo: {
      type: Sequelize.TEXT,
    }
  },
  {
    freezeTableName: true,
    timestamps: false,
  }
);
module.exports = empresa;
