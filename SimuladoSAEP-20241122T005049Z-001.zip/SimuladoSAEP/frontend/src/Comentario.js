import React, { useState } from 'react';
import EditarComentario from './EditarComentario';
import ExcluirComentario from './ExcluirComentario';

function Comentario({ user, onAddComment }) {
    const [comment, setComment] = useState('');
    const [isDisabled, setIsDisabled] = useState(true);

    // Atualiza o comentário
    const handleChange = (e) => {
        setComment(e.target.value);
        setIsDisabled(e.target.value.trim() === ''); // Desabilita o botão se não houver comentário
    };

    const handleSubmit = () => {
        if (comment.trim()) {
            onAddComment({ userName: user.name, comment: comment }); // Envia o comentário
            setComment('');
            setIsDisabled(true);
        }
    };

    return (
        <div>
            <div>{user.name}</div>
            <textarea
                value={comment}
                onChange={handleChange}
                placeholder="Escreva seu comentário..."
            />
            <button onClick={handleSubmit} disabled={isDisabled}>
                Comentar
            </button>
        </div>
    );
}

export default Comentario;
