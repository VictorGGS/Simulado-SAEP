import React, { useState } from 'react';
import Comentario from './Comentario';  // Componente de comentários
import ModalExcluir from './ModalExcluir'; // Modal para exclusão de comentário

const Publicacao = ({ curso, user, onAddComment, onDeleteComment, onEditComment }) => {
  const [isCommenting, setIsCommenting] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState(curso.comentarios); // Recebe lista de comentários
  const [isEditing, setIsEditing] = useState(false);
  const [selectedCommentId, setSelectedCommentId] = useState(null);

  const handleStartComment = () => {
    setIsCommenting(true);
  };

  const handleCommentChange = (e) => {
    setCommentText(e.target.value);
  };

  const handleSubmitComment = () => {
    if (commentText.trim()) {
      onAddComment(commentText, user.nome);  // Função para adicionar comentário ao banco de dados
      setCommentText('');
      setIsCommenting(false);
    }
  };

  const handleDeleteComment = (commentId) => {
    setSelectedCommentId(commentId);
  };

  const handleEditComment = (commentId) => {
    setSelectedCommentId(commentId);
    setIsEditing(true);
  };

  return (
    <div>
      <div className="publicacao">
        {/* Título do curso */}
        <h3>{curso.nome}</h3>
        <button onClick={handleStartComment}>
          <img src="chat.svg" alt="Chat" />
        </button>

        {/* Comentários existentes */}
        {comments.map((comment) => (
          <Comentario
            key={comment.id}
            comment={comment}
            onDelete={handleDeleteComment}
            onEdit={handleEditComment}
          />
        ))}

        {/* Campo para adicionar um novo comentário */}
        {isCommenting && (
          <div>
            <textarea
              value={commentText}
              onChange={handleCommentChange}
              placeholder="Digite seu comentário..."
            />
            <button
              onClick={handleSubmitComment}
              disabled={!commentText.trim()}
              style={{
                backgroundColor: commentText.trim() ? '#C4C4C4' : '#E0E0E0',
                color: '#000',
                textAlign: 'right'
              }}
            >
              Comentar
            </button>
          </div>
        )}
      </div>

      {/* Modal para confirmar exclusão do comentário */}
      {selectedCommentId && (
        <ModalExcluir
          commentId={selectedCommentId}
          onConfirm={() => onDeleteComment(selectedCommentId)}
          onCancel={() => setSelectedCommentId(null)}
        />
      )}
    </div>
  );
};

export default Publicacao;
