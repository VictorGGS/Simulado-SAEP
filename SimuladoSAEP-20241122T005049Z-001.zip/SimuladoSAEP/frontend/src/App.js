// App.js

import React, { useState } from 'react';
import ModalLogin from './ModalLogin';
import ComponenteMain from './ComponenteMain';
import Perfil from './Perfil';

import Comentario from './Comentario';
import EditarComentario from './EditarComentario';
import ExcluirComentario from './ExcluirComentario';

function App() {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [userPhoto, setUserPhoto] = useState(''); // Estado para armazenar a foto do usuário

    const handleInteraction = (actionType) => {
        if (!isLoggedIn) {
            openModal();
        } else {
            if (actionType === 'comment') {
                // Lógica para comentar
            } else if (actionType === 'enroll') {
                // Lógica para inscrição
            }
        }
    };

    const openModal = () => {
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };

    // Função para definir a foto do usuário com base no e-mail
    const handleLoginSuccess = (email) => {
        setIsLoggedIn(true);

        let photo = '';
        if (email === 'marivasco@usuario.com') {
            photo = 'mari_vasco.jpg';
        } else if (email === 'ramiel@usuario.com') {
            photo = 'ramiel_cunha.jpg';
        } else if (email === 'iwindows@usuario.com') {
            photo = 'bill_jobs.jpg';
        }

        setUserPhoto(photo); // Armazena a foto do usuário após login bem-sucedido
        closeModal(); // Fecha o modal após login bem-sucedido
    };

    const [comments, setComments] = useState([]);
    const [user, setUser] = useState({ name: 'Bill Jobs' });

    const addComment = (newComment) => {
        setComments([...comments, { ...newComment, id: comments.length }]);
    };

    const updateComment = (id, updatedComment) => {
        setComments(comments.map(comment =>
            comment.id === id ? { ...comment, comment: updatedComment } : comment
        ));
    };

    const deleteComment = (id) => {
        setComments(comments.filter(comment => comment.id !== id));
    };

    return (
        <div className="App">
            <header>
                <h1>FaculHub – O Curso Certo Para Você</h1>
            </header>

            <main>
                <div className="Esquerda">
                    {isLoggedIn ? (
                        // Exibe a foto de usuário após login (se estiver logado)
                        <img src={userPhoto} alt="Foto de usuário" width={455} />
                    ) : (
                        // Se não estiver logado, exibe o perfil padrão (sem foto)
                        <Perfil openModal={openModal} userPhoto={userPhoto} />
                    )}
                </div>

                <div className="Direita">
                    <ComponenteMain />
                </div>
            </main>

            <ModalLogin
                isOpen={isModalOpen}
                onClose={closeModal}
                onLoginSuccess={handleLoginSuccess} // Passa a função de sucesso de login para o modal
            />
        </div>
    );
}

export default App;
