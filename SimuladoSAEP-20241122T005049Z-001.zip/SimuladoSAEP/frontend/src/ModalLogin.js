// ModalLogin.js

import React, { useState } from 'react';

const ModalLogin = ({ isOpen, onClose, onLoginSuccess }) => {
    const [email, setEmail] = useState('');
    const [senha, setSenha] = useState('');
    const [emailError, setEmailError] = useState('');
    const [senhaError, setSenhaError] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

        setEmailError('');
        setSenhaError('');
        setErrorMessage('');

        // Simulação de verificação de credenciais
        if (email === 'marivasco@usuario.com' && senha === '123456') {
            onLoginSuccess(email); // Passa o e-mail para a função no App.js
        } else if (email === 'ramiel@usuario.com' && senha === '654321') {
            onLoginSuccess(email);
        } else if (email === 'iwindows@usuario.com' && senha === '87654') {
            onLoginSuccess(email);
        } else {
            setErrorMessage('Usuário ou senha incorreto');
            if (!email) setEmailError('Campo obrigatório');
            if (!senha) setSenhaError('Campo obrigatório');
        }
    };

    if (!isOpen) return null;

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <h2>Login</h2>
                {errorMessage && <p className="error-message">{errorMessage}</p>}
                <form onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="email">E-mail</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            style={{ borderColor: emailError ? 'red' : '#ccc' }}
                        />
                        {emailError && <p className="error-text">{emailError}</p>}
                    </div>
                    <div>
                        <label htmlFor="senha">Senha</label>
                        <input
                            type="password"
                            id="senha"
                            value={senha}
                            onChange={(e) => setSenha(e.target.value)}
                            style={{ borderColor: senhaError ? 'red' : '#ccc' }}
                        />
                        {senhaError && <p className="error-text">{senhaError}</p>}
                    </div>
                    <div className="buttons">
                        <button type="button" className="cancel-btn" onClick={onClose}>Cancelar</button>
                        <button type="submit" className="entrar-btn">Entrar</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ModalLogin;
