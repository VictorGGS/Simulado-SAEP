import React, { useState } from 'react';

function ExcluirComentario({ commentId, onDeleteComment }) {
    const [showModal, setShowModal] = useState(false); // Estado do modal

    // Função para deletar o comentário
    const handleDelete = () => {
        onDeleteComment(commentId); // Deleta o comentário
        setShowModal(false); // Fecha o modal
    };

    return (
        <div>
            {/* Ícones de edição e exclusão, alinhados à direita */}
            <div className="header-icons">
                <button onClick={() => setShowModal(true)}>
                    <img className="lixeira-deletar" src="lixeira_deletar.svg" alt="Lixeira"/>
                </button>
            </div>

            {/* Modal de confirmação para exclusão */}
            {showModal && (
                <div className="modal">
                    <p>Tem certeza que deseja excluir este comentário?</p>
                    <button className="entrar-btn" onClick={handleDelete}>Sim</button>
                    <button className="cancel-btn" onClick={() => setShowModal(false)}>Não</button>
                </div>
            )}
        </div>
    );
}

export default ExcluirComentario;
