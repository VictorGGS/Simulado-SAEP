import React, { useState } from 'react';
import Comentario from './Comentario';
import EditarComentario from './EditarComentario';
import ExcluirComentario from './ExcluirComentario';

function ComponenteMain() {
    const [commentsAI, setCommentsAI] = useState([]); // Comentários para Inteligência Artificial
    const [commentsEM, setCommentsEM] = useState([]); // Comentários para Eletromecânica
    const [showCommentsAI, setShowCommentsAI] = useState(false); // Estado para controlar visibilidade dos comentários de IA
    const [showCommentsEM, setShowCommentsEM] = useState(false); // Estado para controlar visibilidade dos comentários de EM
    const [user] = useState({ name: 'Bill Jobs' });

    const addCommentAI = (newComment) => {
        setCommentsAI([...commentsAI, { ...newComment, id: commentsAI.length }]);
    };

    const addCommentEM = (newComment) => {
        setCommentsEM([...commentsEM, { ...newComment, id: commentsEM.length }]);
    };

    const updateCommentAI = (id, updatedComment) => {
        setCommentsAI(commentsAI.map(comment =>
            comment.id === id ? { ...comment, comment: updatedComment } : comment
        ));
    };

    const updateCommentEM = (id, updatedComment) => {
        setCommentsEM(commentsEM.map(comment =>
            comment.id === id ? { ...comment, comment: updatedComment } : comment
        ));
    };

    const deleteCommentAI = (id) => {
        setCommentsAI(commentsAI.filter(comment => comment.id !== id));
    };

    const deleteCommentEM = (id) => {
        setCommentsEM(commentsEM.filter(comment => comment.id !== id));
    };

    // Função para alternar a visibilidade dos comentários de IA
    const toggleCommentsAI = () => {
        setShowCommentsAI(!showCommentsAI);
    };

    // Função para alternar a visibilidade dos comentários de EM
    const toggleCommentsEM = () => {
        setShowCommentsEM(!showCommentsEM);
    };

    return (
        <div>
            <div className="cabeçalho">
                <h2>Cursos</h2>
            </div>

            <div className="InteligênciaArtificial">
                <h3>Inteligência Artificial</h3>
                <h3 className="PUC-MG">PUC-MG</h3>
                <img className="InteligênciaArtificial" src="inteligencia_artificial.png" alt="Inteligência Artificial" width={600} />
                <br />
                <div className="barra">
                    <img src="flecha_cima_vazia.svg" alt="Flecha" />
                      {/* Aqui, você pode substituir o número fixo por a variável de comentários */}
                    <img className="Chat" src="chat.svg" alt="Chat" onClick={toggleCommentsAI} />
                    <p>{commentsAI.length}</p>  {/* Número de comentários */}
                </div>

                {/* Exibe o componente de comentário de IA somente se showCommentsAI for true */}
                {showCommentsAI && (
                    <div>
                        <Comentario user={user} onAddComment={addCommentAI} />
                        <h2>Comentários</h2>
                        {commentsAI.length === 0 ? (
                            <p>Nenhum comentário ainda.</p>
                        ) : (
                            commentsAI.map(comment => (
                                <div  className='divComentario' key={comment.id} style={{ marginBottom: '20px' }}>
                                    <p><strong>{comment.userName}</strong>: {comment.comment}</p>
                                    <EditarComentario className='editComentario' commentData={comment} onUpdateComment={(newComment) => updateCommentAI(comment.id, newComment)}/>
                                    <ExcluirComentario commentId={comment.id} onDeleteComment={deleteCommentAI} />
                                </div>
                            ))
                        )}
                    </div>
                )}
            </div>

            <div className="Eletromecânica">
                <h3>Eletromecânica</h3>
                <h3 className="PUC-MG">PUC-MG</h3>
                <br />
                <img className="Eletromecânica" src="eletromecanica.png" alt="Eletromecânica" width={600} />
                <br />
                <div className="barra">
                    <img src="flecha_cima_vazia.svg" alt="Flecha" />
                      {/* Aqui, você pode substituir o número fixo por a variável de comentários */}
                    <img className="Chat" src="chat.svg" alt="Chat" onClick={toggleCommentsAI} />
                    <p>{commentsAI.length}</p>  {/* Número de comentários */}
                </div>

                {/* Exibe o componente de comentário de IA somente se showCommentsAI for true */}
                {showCommentsAI && (
                    <div>
                        <Comentario user={user} onAddComment={addCommentAI} />
                        <h2>Comentários</h2>
                        {commentsAI.length === 0 ? (
                            <p>Nenhum comentário ainda.</p>
                        ) : (
                            commentsAI.map(comment => (
                                <div key={comment.id} style={{ marginBottom: '20px' }}>
                                    <p><strong>{comment.userName}</strong>: {comment.comment}</p>
                                    <EditarComentario commentData={comment} onUpdateComment={(newComment) => updateCommentAI(comment.id, newComment)} />
                                    <ExcluirComentario commentId={comment.id} onDeleteComment={deleteCommentAI} />
                                </div>
                            ))
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

export default ComponenteMain;
