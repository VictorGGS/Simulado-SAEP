import React from 'react';

const ModalExcluir = ({ commentId, onConfirm, onCancel }) => {
  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h3>Tem certeza que deseja excluir este comentário?</h3>
        <button onClick={onCancel}>Não</button>
        <button onClick={() => onConfirm(commentId)}>Sim</button>
      </div>
    </div>
  );
};

export default ModalExcluir;
