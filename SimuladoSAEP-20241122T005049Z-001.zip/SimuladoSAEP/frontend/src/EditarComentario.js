import React, { useState } from 'react';

function EditarComentario({ commentData, onUpdateComment }) {
    const [newComment, setNewComment] = useState(commentData.comment);
    const [isDisabled, setIsDisabled] = useState(false);

    // Ativa ou desativa a edição
    const handleEdit = () => {
        setIsDisabled(!isDisabled);
    };

    const handleUpdate = () => {
        onUpdateComment(newComment); // Passa o novo comentário
        setIsDisabled(true); // Desabilita o campo após a atualização
    };

    return (
        <div>
            <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}  // Atualiza o estado local
                disabled={isDisabled}
            />
            <button className='edtBTNEditar' onClick={handleUpdate} disabled={isDisabled}>
                <img src='lapis_editar.svg' alt='Lapis Editar'/>
                <p className='Atualizar'>Atualizar</p>
            </button>
        </div>
    );
}

export default EditarComentario;
