import React from 'react';

function Entrar({ onClick }) {
    return (
        <button className="btn-entrar" onClick={onClick}>
            <strong>Entrar</strong>
        </button>  
    );
}

export default Entrar;