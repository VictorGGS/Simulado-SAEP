import React from 'react';

const Perfil = ({ openModal, userPhoto }) => {
    return (
        <div className="perfil">
            <br />
            {/* Exibe o botão "Entrar" para abrir o modal de login */}
            <button onClick={openModal} className="btnentrar">
                Entrar
            </button>
            <br />
            
            {/* Se userPhoto estiver definida, exibe a foto do usuário */}
            {userPhoto ? (
                <img src='bill_jobs.jpg' alt="Foto do Usuário" width={455} />
            ) : (
                // Caso contrário, exibe a logo padrão
                <img src="logo_faculhub.png" alt="Logo Faculhub" width={455} />
            )}

            <h2 className="tituloFaculhub">Faculhub</h2>
            <p>Inscrições: 7</p>
        </div>
    );
};

export default Perfil;